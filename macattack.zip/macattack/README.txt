run python3 mac.py
