1. 
It uses the numpy module so it either needs to be installed or use Anaconda, it has it by default

run $: python AES.py

2.

Only the resources in the project were used to write the AES
(only outside resources were used to remember some numpy methods)

3. 
Passes all test cases
They are run in this order:

C.1 AES-128 (Nk=4, Nr=10)
C.2 AES-192 (Nk=6, Nr=12)
C.3 AES-256 (Nk=8, Nr=14)

4